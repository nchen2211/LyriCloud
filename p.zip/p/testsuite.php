<?php 	
require_once 'PHPUnit/Autoload.php';  
  
class MyTestSuite extends PHPUnit_Framework_TestSuite {  
    public function __construct(){  
          $this->addTestFile('test/clearUpTest.php');  
        }  
  
       //注意此处设置为static  
        public static function suite() {  
       //最后一定得返回PHPUnit_Framework_TestSuite对像  
                return new self();  
        }  
   }
?>