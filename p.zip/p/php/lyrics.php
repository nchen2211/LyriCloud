<?php  
require_once('classes.php');
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 


$artistList = $_SESSION['artists'];
$songList = $_SESSION['songs'];
$wordList = $_SESSION['words'];

$song_id= $_REQUEST["song_id"];

$song = $songList[$song_id];
if ($song == null){
	echo "null";
}else{
	$song_word = $songList[$song_id]->getLyrics();
	//var_dump($song_word);
	echo json_encode($song_word);
}

//$song_word = $songList[$song_id]->getLyrics();

//echo json_encode($song_word);
?>