<?php 		
require_once('classes.php');

    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

$stored_words = $_SESSION["longString"];

$request = $_REQUEST["request"];

if($request == "yes"){
	echo $stored_words;
}

?>