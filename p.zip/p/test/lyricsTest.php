<?php

declare (strict_types=1);


use PHPUnit\Framework\TestCase;

//include ("/var/www/html/LyriCloud_Team9/php/lyriCloud.php");
if (!isset($_SESSION)){
	session_start();
}




final class LyriCloudTest extends TestCase{

	public function testClick(){



		global $artistList;
    	global $songList;
    	global $wordList;

    	 $artistList = array();// stores a list of artist
		 $songList = array();
 		 $wordList = array();


$_SESSION['artists'] = $artistList;
$_SESSION['songs'] = $songList;
$_SESSION['words'] = $wordList;


/*
 		$new_artist = new artistClass();
		$new_artist->setName('Adele');
		$new_artist->setRangeStart('0');
		$new_artist->setRangeEnd('2');		
		array_push($artistList, $new_artist);
*/

		$new_song1 = new songClass();
		$lyrics = 'Sha la la la la la la la Sha la la la la la la la Sha la la la la la la la Sha la la la la It s not the way you smile that touched my heart Sha la la la la It s not the way you kiss';

		$new_song1->setId('0');	
		$new_song1->setName('baby');
		//$songWord1 = array();
		$songWord1 = explode(" ",$lyrics);
		$new_song1->setWordArray($songWord1);
		$new_song1->setLyrics($lyrics);
		$new_song1->setArtist('Adele');		
		array_push($songList, $new_song1);
/*
		$new_song2 = new songClass();
		$lyrics = 'At least I can say that I ve tried I ve tried To tell you I m sorry For breaking your heart But it don t matter It clearly doesn t tear you apart Anymore Ooh anymore Ooh anymore Ooh';
		$new_song2->setId('2');	
		$new_song2->setName('Hello');
		$songWord2 = explode(" ", $lyrics);
		$new_song2->setWordArray($songWord2);
		$new_song2->setLyrics($lyrics);
		$new_song2->setArtist('Adele');		
		array_push($songList, $new_song2);
*/

$_SESSION['artists'] = $artistList;
$_SESSION['songs'] = $songList;
$_SESSION['words'] = $wordList;


		//$a = count($songList);
		//echo $a;
		$_REQUEST["song_id"]= "0";
		
		// if (isset($_REQUEST["clicked_word"])){
		// 	$clickword = $_REQUEST["she"];
		// }

		
		include ("/Library/WebServer/Documents/p/php/lyrics.php");

		$output ='"Sha la la la la la la la Sha la la la la la la la Sha la la la la la la la Sha la la la la It s not the way you smile that touched my heart Sha la la la la It s not the way you kiss"';
		$this -> expectOutputString($output);                  


	}
}