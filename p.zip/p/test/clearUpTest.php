<?php
declare(strict_types=1);
session_start();
use PHPUnit\Framework\TestCase;

$artistList;
$songList;
$wordList ;
$str ;
$artist_name;

final class clearUpTest extends TestCase
{
    public function testClearUp()
    {
        global $artistList ;
        global $songList;
        global $wordList;
        global $str;
        global $artist_name;

        $artistList  = array();
        $songList  = array();
        $wordList  = array();
        $str = "";

        $_SESSION['artists'] = $artistList;
        $_SESSION['songs'] = $songList;
        $_SESSION['words'] = $wordList;
        $_SESSION['longString'] = $str;

       	include_once("/Library/WebServer/Documents/p/php/classes.php");
       	//add five artist into the artistlist
        //add five songs to the songlist
       	for($i = 0; $i<5; $i++){

       		$new_artist = new artistClass();
    		$new_artist->setName("Lady Gaga".$i);
            array_push($artistList, $new_artist);//5 artists in total

            //five songs for each artist
        	$new_song = new songClass();
        	$new_song->setName("song".$i);
        	array_push($songList, $new_song);//25 songs in total
    		
            $new_word = new wordClass();
            $new_word -> setWord("word".$i);
            array_push($wordList, $new_word);

            $str .= "some dummy data";
       	}

		$_SESSION['artists'] = $artistList;
		$_SESSION['songs'] = $songList;
		$_SESSION['words'] = $wordList;
		$_SESSION['longString'] = $str;

        $_REQUEST["artist_name"] = "Justin Bieber";
        $artist_name = "Justin Bieber";
        $_REQUEST["clear"] = "true";

        clearup();
     	// include_once("/Library/WebServer/Documents/LyriCloud_Team9/php/lyriCloud.php");   
        $artistList = $_SESSION['artists'];
        // var_dump($artistList);
     	$artist_count = count($artistList);//should be set so that only contain justin bieber
        $song_count = count($songList);//should be set so that only contain 2 songs of jb
        $word_count = count($wordList);//should be reset to 0 since no word has been selected.

     	$this-> assertEquals(1, $artist_count);
        $this-> assertEquals(2, $song_count);
        $this-> assertEquals(0, $word_count);

    }
}
