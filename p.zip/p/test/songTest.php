<?php

declare (strict_types=1);
//session_start();

if (!isset($_SESSION)){
	session_start();
}

use PHPUnit\Framework\TestCase;

final class SongTest extends TestCase
{
	
	public function setUp(){
		$this->new_song = new songClass();
	/*	 $artistList ;// stores a list of artist
 $songList ;
 $wordList ;
 $str ;
 $lyrics;
 $_SESSION['artists'] = $artistList;
$_SESSION['songs'] = $songList;
$_SESSION['words'] = $wordList;
$_SESSION['longString'] = $str;
*/

	}

	public function tearDown(){
		unset($this->new_song);
	}


	public function testCanBeCreatedAsEmptySongInstance(){
		$this->assertInstanceOf(
			songClass::class,
			new songClass()
			);
		return;
	}

	public function testNewSongName(){

		$new_song = new songClass();
		$songName = 'baby';
		$this->new_song->setName($songName);
		$output = $this->new_song->getName();
		$this->assertEquals($songName, $output);
	}

	public function testNewSongWordArray(){

		$new_song = new songClass();
		$songWord = array("baby", "baby", "oh", "my");

		$new_song->setWordArray($songWord);
		$this->assertEquals($songWord, $new_song->getWordArray());
	}	

	public function testNewSongLyrics(){

		$new_song = new songClass();
		$songLyrics = 'You are my love, you are my heart';

		$new_song->setLyrics($songLyrics);
		$this->assertEquals($songLyrics, $new_song->getLyrics());
	}

	public function testNewSongArtistName(){

		$new_song = new songClass();
		$artistName = 'Lady Gaga';

		$new_song->setArtist($artistName);
		$this->assertEquals($artistName, $new_song->getArtist());
	}


	public function testNewSongWordFrequency(){

		$new_song = new songClass();
		$songWord = array("baby", "baby", "oh", "my");

		$new_song->setWordArray($songWord);
		$testWord1= 'baby';
		$this->assertEquals(2, $new_song->returnCount($testWord1));


		$testWord2= 'o';
		$this->assertEquals(0, $new_song->returnCount($testWord2));
	

	}
	
	public function testWordFrequency(){

		

		global $artistList;
    	global $songList;
    	global $wordList;

    	$artistList = array();// stores a list of artist
		$songList = array();
 		$wordList = array();


		$_SESSION['artists'] = $artistList;
		$_SESSION['songs'] = $songList;
		$_SESSION['words'] = $wordList;






 		$new_artist = new artistClass();
		$new_artist->setName('Adele');
		$new_artist->setRangeStart('0');
		$new_artist->setRangeEnd('2');		
		array_push($artistList, $new_artist);


		$new_song1 = new songClass();
		$lyrics = 'Sha la la la la la la la Sha la la la la la la la Sha la la la la la la la Sha la la la la It s not the way you smile that touched my heart Sha la la la la It s not the way you kiss';

		$new_song1->setId('1');	
		$new_song1->setName('baby');
		//$songWord1 = array();
		$songWord1 = explode(" ",$lyrics);
		$new_song1->setWordArray($songWord1);
		$new_song1->setLyrics($lyrics);
		$new_song1->setArtist('Adele');		
		array_push($songList, $new_song1);

		$new_song2 = new songClass();
		$lyrics = 'At least I can say that I ve tried I ve tried To tell you I m sorry For breaking your heart But it don t matter It clearly doesn t tear you apart Anymore Ooh anymore Ooh anymore Ooh';
		$new_song2->setId('2');	
		$new_song2->setName('Hello');
		$songWord2 = explode(" ", $lyrics);
		$new_song2->setWordArray($songWord2);
		$new_song2->setLyrics($lyrics);
		$new_song2->setArtist('Adele');		
		array_push($songList, $new_song2);

		$_SESSION['artists'] = $artistList;
		$_SESSION['songs'] = $songList;
		$_SESSION['words'] = $wordList;


		include_once ("//Library/WebServer/Documents/p/php/classes.php");

		$word = 'I';
		$output = array();

		$a = countFreq($word);
		//var_dump($a);

		//var_dump($output);

		$key0 = "songID";
        $key1 = "songname";
        $key2 = "freq";
        $key3 = "artist";
        $word_count = 4;
            // $entry =  array("songID" =>$i , "songname" => $song.getName(), "freq" => $word_count);
            
            $entry =  array($key0 =>1 , $key1 => 'Hello', $key2 => $word_count, $key3 => 'Adele');
            array_push($output, $entry);
        

        //var_dump($output);
		//countFreq($word);
		$this->assertEquals($output, countFreq($word));





	}	
	






}