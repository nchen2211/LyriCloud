<?php
declare(strict_types=1);

session_start();


use PHPUnit\Framework\TestCase;

$artistList;
$songList;
$wordList ;
$str ;

final class AddToArtistListTest extends TestCase
{
    public function testAddToArtistList()
    {
        global $artistList ;
        global $songList;
        global $wordList;
        global $str;

        $artistList  = array();
        $songList  = array();
        $wordList  = array();
        $str = "";

        $_SESSION['artists'] = $artistList;
        $_SESSION['songs'] = $songList;
        $_SESSION['words'] = $wordList;
        $_SESSION['longString'] = $str;

        $_REQUEST["artist_name"] = "Justin Bieber";
        $_REQUEST["clear"] = "false";

       	include_once("/Library/WebServer/Documents/p/php/classes.php");
       	//add five artist into the artist list
       	// for($i = 0; $i<5; $i++){
       		$new_artist = new artistClass();
    		$new_artist->setName("Lady Gaga");

	    	$array = array("songName1","songName2","songName3","songName4","songName5");
    		$arraycount = count($array);
    		$new_artist->setRangeStart(0);
    		for($i = 0; $i<$arraycount; $i++){
        		$each = $array[$i];
        		$new_song = new songClass();
        		$new_song->setName($each);
        		$new_song->setArtist("Lady Gaga");
        		array_push($songList, $new_song);//now 5 songs in songlist
    		}
    		$new_artist->setRangeEnd(5);
    		array_push($artistList, $new_artist);//now 1 artist in artistlist
       	// }
       	
    	$current_artist = $new_artist;
    	$start = $current_artist->getRangeStart();//0
    	$end = $current_artist->getRangeEnd();//5

    	for($x = $start; $x < $end; $x++){
    		$lyrics_string = "lyric sentence1, lyric sentence2, lyric sentence3, lyric sentence4, lyric sentence5";
        	$formal_lyrics = explode(",", $lyrics_string);
        	$songList[$x]->setLyrics($formal_lyrics);
        	$word_array = array("lyric", "sentence1","lyric", "sentence2","lyric", "sentence3","lyric", "sentence4","lyric", "sentence5");
        	$songList[$x]->setWordArray($word_array);
        	$temp = trim( preg_replace( "/[^0-9a-z]+/i", " ", $lyrics_string ) );
        	$str.= $temp;
    	}//add lyric string and lyric word array to each of the song, extend $str.
		$_SESSION['artists'] = $artistList;
		$_SESSION['songs'] = $songList;
		$_SESSION['words'] = $wordList;
		$_SESSION['longString'] = $str;

		addToArtistList("Justin Bieber");

     	// include_once("/Library/WebServer/Documents/LyriCloud_Team9/php/lyriCloud.php");   

     	// $artist_count = count($artistList);//2 lady gaga and justin bieber
     	$this-> assertEquals(2, count($artistList));
     	$this-> assertEquals("Lady Gaga", $artistList[0]->getName());
     	$this-> assertEquals("Justin Bieber", $artistList[1]->getName());
     	$this-> assertEquals(5, $artistList[1]->getRangeStart());//JB's song start from 5;
     	$this-> assertEquals(7, $artistList[1]->getRangeEnd());//end at 7;
     	$this-> assertEquals(7, count($songList));//7 songs in song list;
     	$this-> assertEquals("Justin Bieber", $songList[5]->getArtist());
     	$this-> assertEquals("Justin Bieber", $songList[6]->getArtist());
     	$this-> assertEquals(444,count($songList[5]->getWordArray()));
     	$this-> assertEquals(387,count($songList[6]->getWordArray()));
     	$this-> assertEquals(53,count($songList[5]->getLyrics()));     	
     	$this-> assertEquals(29,count($songList[6]->getLyrics()));

    }
}
