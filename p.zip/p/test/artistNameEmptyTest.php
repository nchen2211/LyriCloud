<?php
declare(strict_types=1);

session_start();


use PHPUnit\Framework\TestCase;

$artistList;
$songList;
$wordList ;
$str ;

final class artistNameEmptyTest extends TestCase
{
    public function testArtistNameEmpty()
    {
        global $artistList ;
        global $songList;
        global $wordList;
        global $str;

        $artistList  = array();
        $songList  = array();
        $wordList  = array();
        $str = "";

        $_SESSION['artists'] = $artistList;
        $_SESSION['songs'] = $songList;
        $_SESSION['words'] = $wordList;
        $_SESSION['longString'] = $str;

        $_REQUEST["artist_name"] = "";
        $_REQUEST["clear"] = "false";

        include_once("/Library/WebServer/Documents/p/php/lyriCloud.php");        
        $this->expectOutputString('artist name is empty');
    }
}
