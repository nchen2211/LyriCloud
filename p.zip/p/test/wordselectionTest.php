<?php

declare (strict_types=1);


use PHPUnit\Framework\TestCase;

//include ("/var/www/html/LyriCloud_Team9/php/lyriCloud.php");
if (!isset($_SESSION)){
	session_start();
}




final class LyriCloudTest extends TestCase{

	public function testClick(){



 		 $str = 'Sha la la la la la la la Sha la la la la la la la Sha la la la la la la la Sha la la la la It s not the way you smile that touched my heart Sha la la la la It s not the way you kiss""Sha la la la la la la la Sha la la la la la la la Sha la la la la la la la Sha la la la la It s not the way you smile that touched my heart Sha la la la la It s not the way you kiss'; 


		$_SESSION['longString'] = $str;


		//echo $a;
		$_REQUEST["request"]= "yes";
		
		// if (isset($_REQUEST["clicked_word"])){
		// 	$clickword = $_REQUEST["she"];
		// }

		
		include ("/Library/WebServer/Documents/p/php/wordselection.php");

		$output =  $str;
		$this -> expectOutputString($output); 


	}
}