<?php

declare (strict_types=1);


use PHPUnit\Framework\TestCase;

//include ("/var/www/html/LyriCloud_Team9/php/lyriCloud.php");


final class LyriCloudTest extends TestCase{



	public function testBigString(){



    global $artistList;
    global $songList;
    global $wordList;
    global $str;
			//$this->new_word1

 $artistList = array();// stores a list of artist
 $songList = array();
 $wordList = array();
 $str = '';
 $lyrics = array();	



		$new_artist = new artistClass();
		$new_artist->setName('Adele');
		$new_artist->setRangeStart('0');
		$new_artist->setRangeEnd('1');		
		array_push($artistList, $new_artist);


		$new_song1 = new songClass();
		$new_song1->setId('1');	
		$new_song1->setName('baby');
		$songWord1 = array("baby", "baby", "oh", "my");
		$new_song1->setWordArray($songWord1);
		$new_song1->setLyrics('baby,baby,oh,my');
		$new_song1->setArtist('Adele');		
		array_push($songList, $new_song1);

		$_SESSION['artists'] = $artistList;
		$_SESSION['songs'] = $songList;
		$_SESSION['words'] = $wordList;
		$_SESSION['longString'] = $str;
	
		//$artist_name = $_REQUEST["Adele"];
		$artistName = 'Adele';
		//include ("/var/www/html/LyriCloud_Team9/php/lyriCloud.php");
		bigString($artistName);

		$output = 'Sha la la la la la la la Sha la la la la la la la Sha la la la la la la la Sha la la la la It s not the way you smile that touched my heart Sha la la la la It s not the way you kiss that tears me apart Oh Many Many Many nights go by I sit alone at home and I cry over you What can I do Can t help myself cause baby it s you Sha la la la la la la la Baby it s you Sha la la la la la Sha la la la la You should hear what they say about you Cheat Cheat Sha la la la la They say you never Never Never ever been true Cheat Cheat It doesn t matter what they say I know I m gonna love you any old way What can I do when it s true Don t want nobody Nobody cause baby it s you Sha la la la la la la Baby it s you Sha la la la la la la Yeah Oh Oh Many Many Many nights go by I sit alone at home and I cry over you What can I do Can t help myself cause baby it s you Sha la la la la la la la Baby it s you Sha la la la la la Baby it s you Sha la la la la la Baby it s you';

		$this->assertEquals($str, $output);




	}

}